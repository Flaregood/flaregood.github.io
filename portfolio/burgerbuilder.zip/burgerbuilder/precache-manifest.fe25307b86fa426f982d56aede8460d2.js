self.__precacheManifest = [
  {
    "revision": "0781160a43470cfda2f6",
    "url": "./static/css/main.050c864c.chunk.css"
  },
  {
    "revision": "0781160a43470cfda2f6",
    "url": "./static/js/main.0781160a.chunk.js"
  },
  {
    "revision": "06f505b2d0b4e2834751",
    "url": "./static/js/1.06f505b2.chunk.js"
  },
  {
    "revision": "4a686d48d5a089750c49",
    "url": "./static/js/runtime~main.4a686d48.js"
  },
  {
    "revision": "b8503d262bffbfb7c67fd6762963e7d1",
    "url": "./static/media/burger-logo.b8503d26.png"
  },
  {
    "revision": "efc1eb3e4600967dc89bf39a861872e4",
    "url": "./index.html"
  }
];